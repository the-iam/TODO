function AppName() {
  return <h1>TODO App</h1>;
}

export default AppName;
